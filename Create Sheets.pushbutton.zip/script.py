# -*- coding: utf-8 -*-

from pyrevit import revit, DB, forms, script
from pyrevit.forms import WPFWindow

import os
import re
import csv

from System import Object
from System.Collections.ObjectModel import ObservableCollection
from System.Windows.Media import Brushes


doc = revit.doc
output = script.get_output()

DISCIPLINE_PARAM_NAME = "Discipline"
SHEET_SERIES_PARAM_NAME = "Sheet Series"


class SheetRow(object):
    def __init__(self, discipline, sheet_series, sheet_number, sheet_name, source):
        self.Include = True
        self.Discipline = normalize_value(discipline)
        self.SheetSeries = normalize_value(sheet_series)
        self.SheetNumber = normalize_value(sheet_number)
        self.SheetName = normalize_value(sheet_name)
        self.Source = normalize_value(source)
        self.Exists = False
        self.DuplicateText = "No"
        self.Status = "Ready"

    def validate(self):
        self.Discipline = normalize_value(self.Discipline)
        self.SheetSeries = normalize_value(self.SheetSeries)
        self.SheetNumber = normalize_value(self.SheetNumber)
        self.SheetName = normalize_value(self.SheetName)

        if not self.SheetNumber:
            self.Exists = False
            self.DuplicateText = "No"
            self.Status = "Missing sheet number"
            return

        if not self.SheetName:
            self.SheetName = "Sheet"

        if sheet_exists(self.SheetNumber):
            self.Exists = True
            self.DuplicateText = "Yes"
            self.Status = "Duplicate - will be skipped"
        else:
            self.Exists = False
            self.DuplicateText = "No"
            self.Status = "Ready"


def normalize_value(value):
    if value is None:
        return ""
    try:
        if isinstance(value, float):
            if value.is_integer():
                return str(int(value))
            return str(value)
    except:
        pass
    text = str(value).strip()
    text = text.replace("\xef\xbb\xbf", "")
    text = text.replace(u"\ufeff", "")
    if re.match(r'^\d+\.0$', text):
        return text[:-2]
    return text


def normalize_header(value):
    text = normalize_value(value).lower()
    text = text.replace(" ", "")
    text = text.replace("_", "")
    text = text.replace("-", "")
    text = text.replace(".", "")
    text = text.replace("/", "")
    return text


def is_header(value, target):
    h = normalize_header(value)
    if target == "discipline":
        return h in ["discipline", "tab", "sourcetab", "sheetdiscipline", "trade"]
    if target == "group":
        return h in ["group", "sheetgroup", "series", "sheetseries", "sheetcategory", "category", "package"]
    if target == "number":
        return h in ["revitshortnumber", "shortnumber", "sheetnumber", "revitsheetnumber", "number", "sheetno", "sheetnum", "drawingnumber", "drawingno", "drawingnum"]
    if target == "title":
        return h in ["sheettitle", "title", "sheetname", "name", "drawingtitle"]
    return False


def generate_sheet_number(base_number, index):
    if index == 0:
        return base_number
    match = re.search(r'(\d+)$', base_number)
    if match:
        number_text = match.group(1)
        prefix = base_number[:-len(number_text)]
        next_number = int(number_text) + index
        return prefix + str(next_number).zfill(len(number_text))
    return "{}-{:02d}".format(base_number, index + 1)


def get_titleblocks():
    result = []
    titleblocks = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).WhereElementIsElementType().ToElements()
    for tb in titleblocks:
        type_param = tb.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
        type_name = type_param.AsString() if type_param else tb.Name
        result.append(("{} : {}".format(tb.FamilyName, type_name), tb))
    result.sort(key=lambda x: x[0])
    return result


def get_existing_sheet_numbers():
    existing = set()
    sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
    for sheet in sheets:
        existing.add(sheet.SheetNumber)
    return existing


def refresh_existing_sheet_numbers():
    global EXISTING_SHEET_NUMBERS
    EXISTING_SHEET_NUMBERS = get_existing_sheet_numbers()


def sheet_exists(sheet_number):
    return str(sheet_number) in EXISTING_SHEET_NUMBERS


def get_sheet_text_parameters():
    sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
    if not sheets:
        return []
    names = []
    for param in sheets[0].Parameters:
        try:
            if param.StorageType == DB.StorageType.String:
                names.append(param.Definition.Name)
        except:
            pass
    return sorted(list(set(names)))


def set_text_parameter(element, param_name, value):
    if not param_name:
        return True, ""
    param = element.LookupParameter(param_name)
    if not param:
        return False, "Parameter not found: {}".format(param_name)
    if param.IsReadOnly:
        return False, "Read-only parameter: {}".format(param_name)
    if param.StorageType != DB.StorageType.String:
        return False, "Not a text parameter: {}".format(param_name)
    param.Set(str(value))
    return True, ""


def detect_csv_header(row):
    header_map = {}
    for i, header in enumerate(row):
        if is_header(header, "discipline"):
            header_map["discipline"] = i
        elif is_header(header, "group"):
            header_map["group"] = i
        elif is_header(header, "number"):
            header_map["number"] = i
        elif is_header(header, "title"):
            header_map["title"] = i
    return header_map


def read_csv_rows(path, default_discipline, default_series):
    rows = []
    skipped_reason = ""
    try:
        with open(path, 'rb') as csvfile:
            reader = csv.reader(csvfile)
            header_map = {}
            for row_index, row in enumerate(reader):
                if row_index == 0:
                    header_map = detect_csv_header(row)
                    if "number" not in header_map or "title" not in header_map:
                        skipped_reason = "missing sheet number/title headers"
                        return rows, skipped_reason
                    continue
                if not row:
                    continue
                discipline = default_discipline
                sheet_series = default_series
                if "discipline" in header_map and len(row) > header_map["discipline"]:
                    discipline = normalize_value(row[header_map["discipline"]])
                if "group" in header_map and len(row) > header_map["group"]:
                    sheet_series = normalize_value(row[header_map["group"]])
                sheet_number = normalize_value(row[header_map["number"]]) if len(row) > header_map["number"] else ""
                sheet_name = normalize_value(row[header_map["title"]]) if len(row) > header_map["title"] else ""
                if not sheet_number:
                    continue
                if not sheet_name:
                    sheet_name = "Sheet"
                rows.append((discipline, sheet_series, sheet_number, sheet_name))
    except Exception as ex:
        skipped_reason = str(ex)
    return rows, skipped_reason


EXISTING_SHEET_NUMBERS = get_existing_sheet_numbers()


class EnterpriseSheetCreator(WPFWindow):
    def __init__(self):
        xaml_path = os.path.join(os.path.dirname(__file__), "ui.xaml")
        WPFWindow.__init__(self, xaml_path)
        self.all_rows = ObservableCollection[Object]()
        self.view_rows = ObservableCollection[Object]()
        self.titleblocks = get_titleblocks()
        self.text_params = get_sheet_text_parameters()
        self.setup_ui()
        self.register_events()

    def setup_ui(self):
        self.dg_sheets.ItemsSource = self.view_rows
        for name, tb in self.titleblocks:
            self.cb_titleblock.Items.Add(name)
        if self.titleblocks:
            self.cb_titleblock.SelectedIndex = 0
        for cb in [self.cb_param1, self.cb_param2]:
            cb.Items.Add("")
            for p in self.text_params:
                cb.Items.Add(p)
            cb.SelectedIndex = 0
        self.cb_filter_discipline.Items.Add("All")
        self.cb_filter_series.Items.Add("All")
        self.cb_filter_discipline.SelectedIndex = 0
        self.cb_filter_series.SelectedIndex = 0
        self.update_summary()

    def register_events(self):
        self.btn_preview.Click += self.manual_preview
        self.btn_import_workbook.Click += self.import_workbook_tabs_unavailable
        self.btn_import_flat_excel.Click += self.import_flat_excel_unavailable
        self.btn_import_csv_folder.Click += self.import_csv_folder
        self.btn_import_csv.Click += self.import_csv
        self.btn_apply_filter.Click += self.apply_filter
        self.btn_show_all.Click += self.show_all
        self.btn_remove_selected.Click += self.remove_selected
        self.btn_revalidate.Click += self.revalidate
        self.btn_clear.Click += self.clear_all
        self.btn_create.Click += self.create_sheets
        self.btn_cancel.Click += lambda s, e: self.Close()
        self.dg_sheets.LoadingRow += self.color_rows

    def import_workbook_tabs_unavailable(self, sender, args):
        forms.alert(
            "Excel Interop is not available in your pyRevit environment.\n\n"
            "Use the recommended workflow:\n"
            "1. In Excel, export/save each discipline tab as CSV.\n"
            "2. Save all CSV files in one folder.\n"
            "3. Name each CSV file by discipline, e.g. Architecture.csv, Structure.csv.\n"
            "4. Click 'Import CSV Folder'.\n\n"
            "This preserves discipline using the CSV file name.",
            title="Use CSV Folder Import"
        )

    def import_flat_excel_unavailable(self, sender, args):
        forms.alert(
            "Flat Excel import requires Microsoft.Office.Interop.Excel, which is not available.\n\n"
            "Please save the active Excel sheet as CSV and use 'Import CSV'.",
            title="Use CSV Import"
        )

    def color_rows(self, sender, args):
        try:
            row_item = args.Row.Item
            if not row_item.Include:
                args.Row.Background = Brushes.LightGray
            elif row_item.Exists:
                args.Row.Background = Brushes.MistyRose
            elif row_item.Status != "Ready":
                args.Row.Background = Brushes.LightYellow
            else:
                args.Row.Background = Brushes.White
        except:
            args.Row.Background = Brushes.White

    def update_summary(self):
        total = self.all_rows.Count
        shown = self.view_rows.Count
        included = 0
        ready = 0
        duplicates = 0
        issues = 0
        for row in self.all_rows:
            if row.Include:
                included += 1
            if row.Exists:
                duplicates += 1
            elif row.Status == "Ready":
                ready += 1
            else:
                issues += 1
        self.tb_summary.Text = "Total: {} | Shown: {} | Included: {} | Ready: {} | Duplicates: {} | Issues: {}".format(total, shown, included, ready, duplicates, issues)

    def refresh_view(self):
        try:
            self.dg_sheets.Items.Refresh()
        except:
            pass
        self.update_summary()

    def add_row(self, discipline, sheet_series, sheet_number, sheet_name, source):
        row = SheetRow(discipline, sheet_series, sheet_number, sheet_name, source)
        row.validate()
        self.all_rows.Add(row)
        self.view_rows.Add(row)

    def rebuild_filter_lists(self):
        disciplines = []
        series_list = []
        for row in self.all_rows:
            if row.Discipline and row.Discipline not in disciplines:
                disciplines.append(row.Discipline)
            if row.SheetSeries and row.SheetSeries not in series_list:
                series_list.append(row.SheetSeries)
        disciplines.sort()
        series_list.sort()
        self.cb_filter_discipline.Items.Clear()
        self.cb_filter_series.Items.Clear()
        self.cb_filter_discipline.Items.Add("All")
        self.cb_filter_series.Items.Add("All")
        for d in disciplines:
            self.cb_filter_discipline.Items.Add(d)
        for s in series_list:
            self.cb_filter_series.Items.Add(s)
        self.cb_filter_discipline.SelectedIndex = 0
        self.cb_filter_series.SelectedIndex = 0

    def manual_preview(self, sender, args):
        base = normalize_value(self.tb_base_number.Text)
        name = normalize_value(self.tb_sheet_name.Text)
        discipline = normalize_value(self.tb_default_discipline.Text)
        series = normalize_value(self.tb_default_series.Text)
        if not base:
            forms.alert("Please enter a base sheet number.")
            return
        if not name:
            forms.alert("Please enter a sheet name.")
            return
        try:
            count = int(normalize_value(self.tb_count.Text))
        except:
            forms.alert("Count must be a whole number.")
            return
        if count <= 0:
            forms.alert("Count must be greater than zero.")
            return
        self.all_rows.Clear()
        self.view_rows.Clear()
        for i in range(count):
            sheet_number = generate_sheet_number(base, i)
            sheet_name = name if count == 1 else "{} {}".format(name, i + 1)
            self.add_row(discipline, series, sheet_number, sheet_name, "Manual Preview")
        self.rebuild_filter_lists()
        self.show_all(None, None)

    def import_csv_folder(self, sender, args):
        folder = forms.pick_folder()
        if not folder:
            return
        self.all_rows.Clear()
        self.view_rows.Clear()
        imported_count = 0
        imported_files = []
        skipped_files = []
        csv_files = []
        for file_name in os.listdir(folder):
            if file_name.lower().endswith('.csv'):
                csv_files.append(file_name)
        csv_files.sort()
        for file_name in csv_files:
            path = os.path.join(folder, file_name)
            discipline_from_file = os.path.splitext(file_name)[0]
            rows, skipped_reason = read_csv_rows(path, discipline_from_file, normalize_value(self.tb_default_series.Text))
            if skipped_reason:
                skipped_files.append("{} - {}".format(file_name, skipped_reason))
                continue
            file_count = 0
            for discipline, series, number, title in rows:
                if not discipline:
                    discipline = discipline_from_file
                self.add_row(discipline, series, number, title, "CSV Folder: {}".format(file_name))
                imported_count += 1
                file_count += 1
            imported_files.append("{}: {} rows".format(file_name, file_count))
        self.rebuild_filter_lists()
        self.show_all(None, None)
        output.print_md("# CSV Folder Import Report")
        output.print_md("## Imported CSV Files")
        if imported_files:
            for item in imported_files:
                output.print_md("- {}".format(item))
        else:
            output.print_md("- None")
        output.print_md("## Skipped CSV Files")
        if skipped_files:
            for item in skipped_files:
                output.print_md("- {}".format(item))
        else:
            output.print_md("- None")
        forms.alert("Imported {} rows from {} CSV files.\n\nDiscipline was taken from each CSV file name unless the CSV has a Discipline column.".format(imported_count, len(csv_files)), title="CSV Folder Import Complete")

    def import_csv(self, sender, args):
        path = forms.pick_file(file_ext='csv')
        if not path:
            return
        default_discipline = normalize_value(self.tb_default_discipline.Text)
        default_series = normalize_value(self.tb_default_series.Text)
        self.all_rows.Clear()
        self.view_rows.Clear()
        rows, skipped_reason = read_csv_rows(path, default_discipline, default_series)
        if skipped_reason:
            forms.alert("CSV import failed.\n\n{}".format(skipped_reason), title="CSV Import Error")
            return
        imported_count = 0
        for discipline, series, number, title in rows:
            self.add_row(discipline, series, number, title, "CSV")
            imported_count += 1
        self.rebuild_filter_lists()
        self.show_all(None, None)
        forms.alert("Imported {} rows from CSV.".format(imported_count), title="CSV Import Complete")

    def apply_filter(self, sender, args):
        discipline_filter = str(self.cb_filter_discipline.SelectedItem) if self.cb_filter_discipline.SelectedItem else "All"
        series_filter = str(self.cb_filter_series.SelectedItem) if self.cb_filter_series.SelectedItem else "All"
        self.view_rows.Clear()
        for row in self.all_rows:
            show = True
            if discipline_filter != "All" and row.Discipline != discipline_filter:
                show = False
            if series_filter != "All" and row.SheetSeries != series_filter:
                show = False
            if show:
                self.view_rows.Add(row)
        self.refresh_view()

    def show_all(self, sender, args):
        if self.cb_filter_discipline.Items.Count > 0:
            self.cb_filter_discipline.SelectedIndex = 0
        if self.cb_filter_series.Items.Count > 0:
            self.cb_filter_series.SelectedIndex = 0
        self.view_rows.Clear()
        for row in self.all_rows:
            self.view_rows.Add(row)
        self.refresh_view()

    def remove_selected(self, sender, args):
        selected = []
        for item in self.dg_sheets.SelectedItems:
            selected.append(item)
        if len(selected) == 0:
            forms.alert("Please select rows to remove.")
            return
        proceed = forms.alert("Remove {} selected rows?".format(len(selected)), ok=False, yes=True, no=True, title="Remove Selected")
        if not proceed:
            return
        for item in selected:
            try:
                self.all_rows.Remove(item)
            except:
                pass
            try:
                self.view_rows.Remove(item)
            except:
                pass
        self.rebuild_filter_lists()
        self.refresh_view()

    def revalidate(self, sender, args):
        refresh_existing_sheet_numbers()
        try:
            self.dg_sheets.CommitEdit()
        except:
            pass
        for row in self.all_rows:
            row.validate()
        self.refresh_view()

    def clear_all(self, sender, args):
        self.all_rows.Clear()
        self.view_rows.Clear()
        self.rebuild_filter_lists()
        self.refresh_view()

    def get_global_parameter_assignments(self):
        assignments = []
        used = set()
        pairs = [(self.cb_param1, self.tb_value1), (self.cb_param2, self.tb_value2)]
        for cb, tb in pairs:
            param_name = cb.SelectedItem
            if param_name is None:
                continue
            param_name = normalize_value(param_name)
            if not param_name:
                continue
            if param_name in used:
                continue
            used.add(param_name)
            assignments.append((param_name, normalize_value(tb.Text)))
        return assignments

    def create_sheets(self, sender, args):
        if self.all_rows.Count == 0:
            forms.alert("No rows to create.")
            return
        if not self.titleblocks:
            forms.alert("No title blocks found in this project.")
            return
        if self.cb_titleblock.SelectedIndex < 0:
            forms.alert("Please select a title block.")
            return
        try:
            self.dg_sheets.CommitEdit()
        except:
            pass
        self.revalidate(None, None)
        ready_rows = []
        duplicate_rows = []
        excluded_rows = []
        issue_rows = []
        for row in self.all_rows:
            if not row.Include:
                excluded_rows.append(row)
            elif row.Exists:
                duplicate_rows.append(row)
            elif row.Status == "Ready":
                ready_rows.append(row)
            else:
                issue_rows.append(row)
        if len(ready_rows) == 0:
            forms.alert("No valid included sheets to create.")
            return
        confirm_msg = "Ready to create: {}\nDuplicates to skip: {}\nExcluded rows: {}\nRows with issues: {}\n\nContinue?".format(len(ready_rows), len(duplicate_rows), len(excluded_rows), len(issue_rows))
        proceed = forms.alert(confirm_msg, ok=False, yes=True, no=True, title="Confirm Sheet Creation")
        if not proceed:
            return
        titleblock = self.titleblocks[self.cb_titleblock.SelectedIndex][1]
        global_assignments = self.get_global_parameter_assignments()
        created = []
        skipped = []
        warnings = []
        with revit.Transaction("Enterprise Create Sheets"):
            for row in self.all_rows:
                row.validate()
                if not row.Include:
                    skipped.append("{} - excluded".format(row.SheetNumber))
                    continue
                if row.Exists:
                    skipped.append("{} - duplicate".format(row.SheetNumber))
                    continue
                if row.Status != "Ready":
                    skipped.append("{} - {}".format(row.SheetNumber, row.Status))
                    continue
                try:
                    sheet = DB.ViewSheet.Create(doc, titleblock.Id)
                    sheet.SheetNumber = str(row.SheetNumber)
                    sheet.Name = str(row.SheetName)
                    ok1, msg1 = set_text_parameter(sheet, DISCIPLINE_PARAM_NAME, row.Discipline)
                    if not ok1:
                        warnings.append("{} - {}".format(row.SheetNumber, msg1))
                    ok2, msg2 = set_text_parameter(sheet, SHEET_SERIES_PARAM_NAME, row.SheetSeries)
                    if not ok2:
                        warnings.append("{} - {}".format(row.SheetNumber, msg2))
                    for param_name, value in global_assignments:
                        if param_name in [DISCIPLINE_PARAM_NAME, SHEET_SERIES_PARAM_NAME]:
                            continue
                        ok, msg = set_text_parameter(sheet, param_name, value)
                        if not ok:
                            warnings.append("{} - {}".format(row.SheetNumber, msg))
                    row.Status = "Created"
                    created.append("{} - {}".format(row.SheetNumber, row.SheetName))
                except Exception as ex:
                    row.Status = "Failed"
                    skipped.append("{} - {}".format(row.SheetNumber, str(ex)))
        refresh_existing_sheet_numbers()
        for row in self.all_rows:
            if str(row.SheetNumber) in EXISTING_SHEET_NUMBERS:
                row.Exists = True
                row.DuplicateText = "Yes"
                if row.Status == "Created":
                    row.Status = "Created / Exists"
        self.refresh_view()
        output.print_md("# Enterprise Sheet Creator Report")
        output.print_md("## Created Sheets")
        if created:
            for item in created:
                output.print_md("- {}".format(item))
        else:
            output.print_md("- None")
        output.print_md("## Skipped Rows")
        if skipped:
            for item in skipped:
                output.print_md("- {}".format(item))
        else:
            output.print_md("- None")
        output.print_md("## Parameter Warnings")
        if warnings:
            for item in warnings:
                output.print_md("- {}".format(item))
        else:
            output.print_md("- None")
        forms.alert("Sheet creation completed.\n\nCreated: {}\nSkipped: {}\nWarnings: {}".format(len(created), len(skipped), len(warnings)), title="Sheet Creation Complete")


EnterpriseSheetCreator().ShowDialog()
